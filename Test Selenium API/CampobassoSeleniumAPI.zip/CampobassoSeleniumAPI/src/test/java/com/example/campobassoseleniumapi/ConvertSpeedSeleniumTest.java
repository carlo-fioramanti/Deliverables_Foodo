package com.example.campobassoseleniumapi;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
public class ConvertSpeedSeleniumTest {

    //FLAVIO CAMPOBASSO

    @Test
    public void convertSpeedTest(){

        ConvertSpeedSelenium convertSpeedSelenium = new ConvertSpeedSelenium();
        String
                m_s = convertSpeedSelenium.SpeedConv("2");
        assertEquals("2 000 Metro al secondo [m/s]", m_s);
    }
}
