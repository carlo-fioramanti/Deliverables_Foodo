package com.example.campobassoseleniumapi;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

// page_url = https://www.jetbrains.com/
public class ConvertSpeedSelenium {

    //FLAVIO CAMPOBASSO

    public String SpeedConv(String v){
        System.setProperty("webdriver.chrome.drievr", "C:\\Users\\flavi\\Desktop\\università\\ISPW\\PROJECT\\CampobassoSeleniumAPI\\src\\test\\java\\driver\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        ChromeDriver driver = new ChromeDriver(options);

        driver.get("https://www.convertire-unita.info/convertire+Chilometro+al+secondo+in+Metro+al+secondo.php");

        try{
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"valore\"]")).click();

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement input = driver.findElement(By.xpath("//*[@id=\"valore\"]"));
        input.sendKeys(v);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.xpath("/html/body/div/main/div/div[2]/article/div[2]/form[2]/p[5]/input")).click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String m_s = driver.findElement(By.xpath("/html/body/div/main/div/div[2]/article/div[3]/strong")).getAttribute("textContent");
        driver.close();
        return m_s;

    }
}
