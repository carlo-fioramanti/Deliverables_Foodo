package com.example.fioramantiseleniumapi;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.chrome.ChromeOptions;
import com.codeborne.selenide.logevents.SelenideLogger;
import io.qameta.allure.selenide.AllureSelenide;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

import static com.codeborne.selenide.Condition.attribute;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class DerivativeCalculatorTest {
    // FIORAMANTI

    @Test
    public void calculateDerivative(){
        DerivativeCalculator derivativeCalculator= new DerivativeCalculator();
        String der= derivativeCalculator.calcDer("3x");
        assertEquals("3", der);
    }
}
