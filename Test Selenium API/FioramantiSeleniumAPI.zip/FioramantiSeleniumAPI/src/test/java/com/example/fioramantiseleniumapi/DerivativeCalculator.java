package com.example.fioramantiseleniumapi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import static com.codeborne.selenide.Selenide.$;

// page_url = https://www.jetbrains.com/
public class DerivativeCalculator {

    //FIORAMANTI

    public String calcDer(String function){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\carlo\\Desktop\\PROGETTO_ISPW\\FioramantiSeleniumAPI\\src\\test\\java\\driver\\chromedriver.exe");

        ChromeOptions options=new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        ChromeDriver driver = new ChromeDriver(options);

        driver.get("https://mathdf.com/der/it/");

        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"input-expression\"]")).click();

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement input= driver.findElement(By.xpath("//*[@id=\"input-expression\"]"));
        input.sendKeys(function);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"solve\"]")).click();

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String derivative = driver.findElement(By.xpath("//*[@id=\"math-canvas\"]/div/div[2]/div/div[8]/span/span/span/span/span/span[2]")).getAttribute("textContent");
        driver.close();
        return derivative;


    }


}
